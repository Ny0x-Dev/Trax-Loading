# cyberload
FiveM Multiplayer loading screen

## Download & Installation

### Using Git
```
cd resources
git clone https://github.com/jumpjet91/cyberload.git cyberload
```

### Manually
- Download https://github.com/jumpjet91/cyberload/archive/master.zip
- UnZip
- Put it in the `resources` directory

## Installation
- Add this in your `server.cfg`:

```
start cyberload
```
## Setting 
Go in index.html and replace this line
```
var AudioFile = 'audio.ogg';
var BackgroundFile = 'background.png';
var LogoFile = 'logo.png';
var ColorWawe = '#10f5ff';
var AudioVolume = 0.2;
var Discord = 'https://discord.gg/XXXXXXX';
```
# Video DEMO
```
https://streamable.com/sbqti
```
# Legal
### License
```
Powered by jumpjet
Fivem profile https://forum.fivem.net/u/jumpjet/
Discord BlackFox91#0053
```
Don't reshare or change credit 
